document.getElementById("clickbutton").addEventListener("click", async function() {

    let text = document.getElementById("userText").value;

    let aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer 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"
        },
        body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [{ role: "user", content: text }]
        })
    });

    let aiData = await aiResponse.json();
    let replyText = aiData.choices[0].message.content;

    let murfResponse = await fetch("https://api.murf.ai/v1/speech/generate", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "api-key": "ap2_b067f808-5f27-496e-938e-828b32f21e97"
        },
        body: JSON.stringify({
            text: replyText,
            voiceId: "en-US-natalie"
        })
    });

    let murfData = await murfResponse.json();

    document.getElementById("reply").src = murfData.audioFile;

});